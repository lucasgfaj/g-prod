class Produto < ApplicationRecord
end
